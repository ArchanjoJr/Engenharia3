package controller;
import java.util.Date;

import  model.*;

public class RelatorioEstoquista implements Relatorio {


	private int idProduto;
	private int qtdProduto;
	private String fornecedor;
	private Date dataEntrada;
	
	public void gerarRelatorio(SpecProduto busca){
		
	}
	
}
