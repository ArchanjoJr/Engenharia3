package controller;
import  model.*;
public interface Relatorio {

	public void gerarRelatorio( SpecProduto busca);
	
}
