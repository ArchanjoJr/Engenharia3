package controller;
import  model.*;

public class RelatorioVendedor implements Relatorio {
	private int preco;
	private int qtdProduto;
	private String descricao;
	private String nomeProduto;
	
	public void gerarRelatorio(SpecProduto busca){
		
	}
}
