package model;

public enum Funcao {

	Estoquista,Vendedor,gerente;
	
}
