package view;

import java.util.List;

import controller.*;

public class ViewRelatorio implements Observer {

	private Relatorio relatorio;
	private List listaObserver;

	public void update(List l){
		
	}
	public void updateMsg(String m){
		
	}
}
