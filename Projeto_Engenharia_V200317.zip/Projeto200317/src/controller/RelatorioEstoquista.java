package controller;
import java.util.Date;
import  model.*;
import java.util.LinkedList;
public class RelatorioEstoquista implements Relatorio {


	private int idProduto;
	private int qtdProduto;
	private String fornecedor;
	private Date dataEntrada;
	
	public void gerarRelatorio(SpecProduto busca){
		
		
	}
	
}
