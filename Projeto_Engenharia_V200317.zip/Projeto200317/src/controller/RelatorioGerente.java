package controller;
import  model.*;

public class RelatorioGerente implements Relatorio{
	private String nomeProduto;
	private int qtdProduto;
	private SpecProduto especificacao;
	
	public void gerarRelatorio(SpecProduto busca){
		
	}
}
